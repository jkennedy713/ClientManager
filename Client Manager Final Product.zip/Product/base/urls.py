from django.urls import path
from .views import ClientList, ClientDetail, ClientCreate, ClientUpdate, DeleteView, CustomLoginView
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('', ClientList.as_view(), name='clients'),
    path('client/<int:pk>/', ClientDetail.as_view(), name='client'),
    path('client-create/', ClientCreate.as_view(), name='client-create'),
    path('client-update/<int:pk>/', ClientUpdate.as_view(), name='client-update'),
    path('client-delete/<int:pk>/', DeleteView.as_view(), name='client-delete'),
]
