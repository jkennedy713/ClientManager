from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, FormView
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.db.models import Q
from .models import Client


class CustomLoginView(LoginView):
    template_name = 'base/login.html'
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy('clients')


class RegisterPage(FormView):
    template_name = 'base/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('clients')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super().form_valid(form)

    def get(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('clients')
        return super().get(request, *args, **kwargs)


class ClientList(LoginRequiredMixin, ListView):
    model = Client
    context_object_name = 'clients'
    paginate_by = 10

    def get_queryset(self):
        query = self.request.GET.get('search-area')
        if query:
            return Client.objects.filter(
                Q(title__icontains=query) | Q(description__icontains=query),
                user=self.request.user
            )
        return Client.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['count'] = self.get_queryset().filter(complete=False).count()
        context['search_input'] = self.request.GET.get('search-area', '')
        return context


class ClientDetail(LoginRequiredMixin, DetailView):
    model = Client
    context_object_name = 'client'
    template_name = 'base/client.html'


class ClientCreate(LoginRequiredMixin, CreateView):
    model = Client
    fields = ['title', 'description', 'complete']
    success_url = reverse_lazy('clients')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class ClientUpdate(LoginRequiredMixin, UpdateView):
    model = Client
    fields = ['title', 'description', 'complete']
    success_url = reverse_lazy('clients')

    def get_queryset(self):
        return self.model.objects.filter(user=self.request.user)


class ClientDelete(LoginRequiredMixin, DeleteView):
    model = Client
    context_object_name = 'client'
    success_url = reverse_lazy('clients')

    def get_queryset(self):
        return self.model.objects.filter(user=self.request.user)
